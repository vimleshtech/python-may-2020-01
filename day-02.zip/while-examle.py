#while example

i =1#init
while i<=10: #condition 
    print(i)
    i+=1 #incrementer

#print in same line
i =1#init
while i<=10: #condition 
    print(i,end='') #end ='' don't chnage the line 
    i+=1 #incrementer
    

#print in reverse
i=10
while i>0:
    print(i)
    i-=1


#wap to get sum of all numbers between two given range
n1= int(input('enter data :')) #start from 
n2= int(input('enter data :')) #till 

s= 0
while n1<=n2: #condition 
    s +=n1  #keep adding the number
    n1+=1 #incrementer
    
print('sum of all numbers :',s)











    











    
    
