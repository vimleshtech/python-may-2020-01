#if elif condition
sales_amt = int(input('enter amt :'))

tax = 0
if sales_amt>10000:
    tax =sales_amt*.18
elif sales_amt>1000:
    tax =sales_amt*.12
elif sales_amt>500:
    tax =sales_amt*.05
elif sales_amt>200:
    tax =sales_amt*.02
    
#get total amt
total = sales_amt+tax

print('total amt is ',total)
