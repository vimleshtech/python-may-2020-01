#for loop
for x in range(10): # 0 to 9
    print(x)
    

#
for x in range(1,10): #1 to 9
    print(x)

#reverse
for x in range(10,0,-1):
    print(x)
    
    
