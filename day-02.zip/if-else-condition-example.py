#if condition
sales_amt = int(input('enter amt :'))

tax = 0
if sales_amt>1000:
    tax =sales_amt*.18
else:
    tax =sales_amt*.05
    
#get total amt
total = sales_amt+tax

print('total amt is ',total)
