#nested condition : if condition inside if condition
n1 = int(input('enter data :'))
n2 = int(input('enter data :'))
n3 = int(input('enter data :'))

if n1>n2:
    if n1>n3:
        print('n1 is greater')
    else:
        print('n3 is greater')
else:
    if n2>n3:
        print('n2 is greater')
    else:
        print('n3 is greater')


##or
if n1>n2 and n1>n3:
    print('n1 is greater')
elif n2>n1 and n2>n3:
    print('n2 is greater')
else:
    print('n3 is greater')

    
    


