#Q7.
a= int(input('enter data :'))
b= int(input('enter data :'))
c= int(input('enter data :'))
d= int(input('enter data :'))

if a**3+b**3+c**3 == d**3:
    print('satisfied')
else:
    print('non satisfied')


    
