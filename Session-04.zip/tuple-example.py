#tuple: data cannot be inserted dynamically in tuple 
t =('Mon','Tue','Wed','Thu','Fri')
print('print all elements ',t)

#print selected values by index and range
print('print all elements ',t[0])
print('print all elements ',t[0:3])

print(t[::-1])

'''
allowed:
--------------
max()
min()
sum()
len()
slicer
count()

not allowed:
--------------
t[1] = newdata
append()
pop()
insert()
remove()
extend()
sort()
reverse()
'''




