#declare dict
d ={'a':'alpha',1:'one',2:'two hundred','t':'tata'}

print(d) #print all keys and values
print(d['a']) #get value of given key

#modify value
d['t']='total global'
print(d)


#add new key and value
d['z']='zebra'
print(d)

#remove key and value
del d['a']
print(d)

#get all keys
print(d.keys())

#get all values
print(d.values())

#get key and values list
print(d.items())

#iterate the keys
print('---- all keys ----')
for k in d.keys():
    print(k)

#iterate the values
print('---- all values ----')
for v in d.values():
    print(v)

#iterate key and values
print('---print key and values--- ')
for k,v in d.items():
    print(k,v)
    
##search value by given keys
find = input('enter key ')
for k in d.keys():
    if k ==find:
        print(d[k])
        
#search key by given value
find = input('enter value to search ')
for k,v in d.items():
    if v ==find:
        print(k)





        
        








    















