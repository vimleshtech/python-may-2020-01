#create function
def func_name():
    print('Hi, this is test code ')

#print function address
print(func_name)
#call (invoke) to function
func_name()
func_name()

