#a. no argument no return
def wel():
    print('we are learning function , and there are several method in this file ')
    print('a. wel, b. getnum c. add d. mul ')
    

#b. no argument with return
def getNum():
    a =int(input('enter data :'))
    b =int(input('enter data :'))
    return a,b #return two values

    
#c. argument with no return
def addNum(a,b):
    c =a+b
    print('addition of two numbers ',c)
    
#d. argument with return
def sub(a,b):
    c =a-b
    return c
	


#call to function s
wel()
addNum(11,455)
addNum(10,55)

x,y = getNum()
print(x,y)
addNum(x,y)

o =sub(x,y)
print(o)



