data={11,4,5,666,11}
print(data)
for r in data:
    print(r)
    




