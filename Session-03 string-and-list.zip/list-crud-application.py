#CRUD (Create,Read,Update,Delete) Operation

sales = [] #empty list

while True: #condition is true , will execute for infinte time
    ch = input('enter 1 for new value, 2 for show values, 3 for delete 4 of udpate , and 0 fo exist ')

    if ch =='1':
        val =input('enter data ')
        sales.append(val)
    elif ch=='2':
        print(sales)
    elif ch=='3':
        d =input('enter value which you want to remove ')
        if d in sales:
            sales.remove(d)
        else:
            print('given value is not found ')
    elif ch=='4':
        ind = int(input('enter poistion where you want to change value '))
        if ind>=0 and ind<len(sales):
            nv = input('enter new value ')
            sales[ind]= nv

    elif ch =='0':
        break
    else:
        print('Invalid choice, plz try again !!!')
        
        



            





        
        
    
