s = input('enter string ')

print(s.upper())
print(s.lower())
print(s.title())

print(s.capitalize())
print(s.swapcase()) #convert lower to upper and upper to lower


print(s.strip())
print(s.lstrip())
print(s.rstrip())
print(len(s))


s.replace('a','xy')
print(s)

o =list(s)
print(o)

c = s.count('i')
print('count of i',c)

print(s[0:4])
print(s[1])
print(s[-1]) #last char


if s.isdigit():
    print('number ')
else:
    print('string ')


if s.isupper():
    print('in upper case ')
else:
    print('in lower case ')


if s.islower():
    print('in lower case ')
else:
    print('in other case ')



if s.startswith('a'):
    print('start with a')
else:
    print('not start with a')
    


if s.endswith('n'):
    print('end with n')
else:
    print('not end with n')






    
    













    














