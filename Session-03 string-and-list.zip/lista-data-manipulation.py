data=[11,3,5,6,4,7,44,4,333]

#add value at last
data.append(100)
print(data)

data.append(200)
print(data)


#remove from last
data.pop()
print(data)


#insert at given position
data.insert(1,345)
print(data)

#find and remove
data.remove(3)
print(data)

if 444 in data:
    data.remvoe(444)

#get count of given value
c = data.count(4)
print('count of 4 ',c)


#convert to set : duplicate value will be removed
ss = set(data)
print(ss)


#return data from given index
print(data[0]) #first value
print(data[0:4]) #from 0 to <4
print(data[:4]) #from 0 to <4
print(data[-1]) #return last value
print(data[::-1]) #from lat to first, in reverse


#edit value or change value
data[1] ='test user'
print(data)




















    
















