sales =[111,4,5,6,6676,333,666]

print('all data ',sales)
print('get 2nd value ',sales[1])

print('get count of elements ',len(sales))


print('highest value ',max(sales))
print('lowest value ',min(sales))
print('total/sum ',sum(sales))

sales.sort() #in asc
print('sorted value in asc ',sales)
sales.reverse()
print('in reverse',sales)

x= sales.copy()
print(x)
print(sales)

a =[11,3,5,66]
b =[444,6,77]
#extend : merge two list
a.extend(b)
print(a)

#list : convert string to list
s ='this is test code'
ns=list(s)
print(ns)








