#example 1
import mylib

mylib.add(114,5)
r = mylib.mul(556,6)
print(r)
o = mylib.div(65,6)
print(0)

#example 2
import mylib as m
m.add(11,55)


#example 3
from mylib import *
add(11,5)
a= mul(5,6)
print(a)

#exaple 4
from mylib import mul
a = mul(115,5)
print(a)











