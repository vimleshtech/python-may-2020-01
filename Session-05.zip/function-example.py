#- argument with default value
def add(a,b=0,c=0,d=0):
    total =a+b+c+d
    print('total value ',total)
    
#- argument with dynamic count of values
def getSum(*arg): #receive all the input/parameter in tuple format
    print(type(arg))
    print(arg)
    s =0
    for x in arg:
        s+=x
    print('total ',s)    
    
#- recurrsive function : function call or invoke to itself
def fact(n):
    if n ==1:
        return n
    else:
        return n*fact(n-1) #5 * 4 *3 * 2 *1
    
     
#- lambda / anonyms function
tax = lambda amt : amt*.18
'''
def tax(amt):
    a =amt*.18
    return a
'''

#- inner/wrapper function (function inside function)
def parent():

    print('before inner ')
    
    def inner():
        print('inside inner function ')

    inner()
    print('after inner ')
    
#invoke or call to function
add(1)
add(1,55)
add(55,767,1)
add(1,6,77,444)

getSum(1,44,66,3,56,4)
getSum(1,44,66,3,56,4,5,3,33,5,6,33)


f =fact(6)
print(f)


print(tax(12000))


parent()

