#module : is collection of functions or classes
#module  is also known as package


def add(a,b):
    c =a+b
    print(c)
def mul(a,b):
    c =a*b
    return c
def div(n1,n2):
    n =n1/n2
    return n


    
